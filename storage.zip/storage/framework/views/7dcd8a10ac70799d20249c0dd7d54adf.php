<?php $__env->startSection('title', 'Tutorials | GeoLearn'); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/w3learn.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="w3">

    <?php echo $__env->make('learning.topnav', ['navCourses' => $courses, 'activeSlug' => null], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="w3-hero">
        <h1>GIS Tutorials</h1>
        <p>Choose a course and learn GIS step by step.</p>
    </div>

    <div class="w3-index">
        <h2>Explore courses</h2>

        <?php if($courses->isEmpty()): ?>
            <p style="padding:40px;text-align:center;color:#5f6368">No courses available yet.</p>
        <?php else: ?>
            <div class="w3-grid">
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="w3-course">
                        <h3><?php echo e($course->title); ?></h3>

                        <div class="tags">
                            <?php if($course->level): ?>
                                <span class="tag"><?php echo e($course->level); ?></span>
                            <?php endif; ?>
                            <span class="tag">
                                <?php echo e($course->is_free ? 'FREE' : number_format($course->price, 2) . ' USD'); ?>

                            </span>
                        </div>

                        <p><?php echo e(\Illuminate\Support\Str::limit($course->description, 160)); ?></p>

                        <div class="count"><?php echo e($course->modules_count); ?> modules</div>

                        <a href="<?php echo e(route('learning.course', $course->slug)); ?>" class="go">Start Learning &raquo;</a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\xampp\gealearn\resources\views/learning/index.blade.php ENDPATH**/ ?>