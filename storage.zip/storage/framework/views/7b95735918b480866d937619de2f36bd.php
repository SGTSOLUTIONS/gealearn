
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title', 'GeoLearn GIS'); ?></title>

    <!-- Bootstrap 5 -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <!-- Bootstrap Icons -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
        rel="stylesheet"
    >

    <!-- OpenLayers CSS (for GIS map pages) -->
    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/ol@10.6.1/ol.css"
    >

    <!-- Page-specific CSS -->
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>

    <!-- Main page content -->
    <?php echo $__env->yieldContent('content'); ?>

    <!-- Bootstrap JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <!-- OpenLayers JavaScript (for GIS map pages) -->
    <script src="https://cdn.jsdelivr.net/npm/ol@10.6.1/dist/ol.js"></script>

    <!-- Page-specific JavaScript -->
    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\xampp\gealearn\resources\views/layouts/app.blade.php ENDPATH**/ ?>