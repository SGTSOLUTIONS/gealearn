

<nav class="w3-topnav">
    <a href="<?php echo e(route('learning.index')); ?>" class="<?php echo e(empty($activeSlug) ? 'active' : ''); ?>">All</a>
    <?php $__currentLoopData = $navCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('learning.course', $c->slug)); ?>"
           class="<?php echo e(($activeSlug ?? null) === $c->slug ? 'active' : ''); ?>"><?php echo e($c->title); ?></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</nav>
<?php /**PATH C:\xampp\htdocs\xampp\gealearn\resources\views/learning/topnav.blade.php ENDPATH**/ ?>