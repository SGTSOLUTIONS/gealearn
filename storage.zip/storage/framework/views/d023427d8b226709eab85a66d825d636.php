<?php $__env->startSection('title', ($lesson->title ?? 'Course') . ' | ' . $course->title . ' | GeoLearn'); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/w3learn.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<?php
    $currIndex = $lesson ? $flatLessons->search(fn ($l) => $l->id === $lesson->id) : false;
    $prev = ($currIndex !== false && $currIndex > 0) ? $flatLessons[$currIndex - 1] : null;
    $next = ($currIndex !== false) ? ($flatLessons[$currIndex + 1] ?? null) : null;
    $percent = $totalLessons > 0 ? round(($lessonIndex / $totalLessons) * 100) : 0;
?>

<div class="w3">

    <?php echo $__env->make('learning.topnav', ['navCourses' => $navCourses, 'activeSlug' => $course->slug], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="w3-shell">

        
        <aside class="w3-sidebar">
            <a href="<?php echo e(route('learning.index')); ?>" class="all-link">&larr; All courses</a>
            <h3 class="side-title"><?php echo e($course->title); ?></h3>

            <?php $__currentLoopData = $course->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $isOpen = $lesson && $module->lessons->contains('id', $lesson->id); ?>
                <details <?php echo e(($isOpen || ($loop->first && !$lesson)) ? 'open' : ''); ?>>
                    <summary><?php echo e($module->title); ?></summary>
                    <?php $__currentLoopData = $module->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('learning.lesson', ['course' => $course->slug, 'lesson' => $l->slug ?: $l->id])); ?>"
                           class="lesson-item <?php echo e($lesson && $lesson->id === $l->id ? 'active' : ''); ?>">
                            <?php echo e($l->title); ?>

                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </details>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </aside>

        
        <main class="w3-main">
            <?php if($lesson): ?>

                <div class="w3-pn">
                    <?php if($prev): ?>
                        <a class="btn" href="<?php echo e(route('learning.lesson', ['course' => $course->slug, 'lesson' => $prev->slug ?: $prev->id])); ?>">&#10094; Previous</a>
                    <?php endif; ?>
                    <span class="spacer"></span>
                    <?php if($next): ?>
                        <a class="btn" href="<?php echo e(route('learning.lesson', ['course' => $course->slug, 'lesson' => $next->slug ?: $next->id])); ?>">Next &#10095;</a>
                    <?php endif; ?>
                </div>

                <h1><?php echo e($lesson->title); ?></h1>
                <div class="lesson-meta">Lesson <?php echo e($lessonIndex); ?> of <?php echo e($totalLessons); ?> &middot; <?php echo e($course->title); ?></div>

                <article class="w3-article">
                    <?php if($customView): ?>
                        
                        <?php echo $__env->make($customView, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php else: ?>
                        <?php echo $lesson->content; ?>

                    <?php endif; ?>
                </article>

                <div class="w3-pn bottom">
                    <?php if($prev): ?>
                        <a class="btn" href="<?php echo e(route('learning.lesson', ['course' => $course->slug, 'lesson' => $prev->slug ?: $prev->id])); ?>">&#10094; Previous</a>
                    <?php endif; ?>
                    <span class="spacer"></span>
                    <?php if($next): ?>
                        <a class="btn" href="<?php echo e(route('learning.lesson', ['course' => $course->slug, 'lesson' => $next->slug ?: $next->id])); ?>">Next &#10095;</a>
                    <?php endif; ?>
                </div>

            <?php else: ?>
                <div style="padding:60px 20px;text-align:center;color:#5f6368">
                    <h3>No lessons yet</h3>
                    <p>This course does not have any lessons added.</p>
                </div>
            <?php endif; ?>
        </main>

        
        <aside class="w3-right">
            <div class="w3-card">
                <h4>Your progress</h4>
                <div class="w3-progress"><span style="width: <?php echo e($percent); ?>%"></span></div>
                <small>Lesson <?php echo e($lessonIndex); ?> of <?php echo e($totalLessons); ?> (<?php echo e($percent); ?>%)</small>
            </div>

            <div class="w3-card">
                <h4>Course info</h4>
                <div class="row"><span>Level</span><strong><?php echo e($course->level ?? '-'); ?></strong></div>
                <div class="row"><span>Modules</span><strong><?php echo e($course->modules->count()); ?></strong></div>
                <div class="row"><span>Lessons</span><strong><?php echo e($totalLessons); ?></strong></div>
                <div class="row"><span>Price</span><strong><?php echo e($course->is_free ? 'FREE' : number_format($course->price, 2) . ' USD'); ?></strong></div>
            </div>
        </aside>

    </div>
</div>

<script src="<?php echo e(asset('js/w3learn.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\xampp\gealearn\resources\views/learning/course.blade.php ENDPATH**/ ?>